package clientManager;

public class LoadingAnim implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("loading");
	}

}
