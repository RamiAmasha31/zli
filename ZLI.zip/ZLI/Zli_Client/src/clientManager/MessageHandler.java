package clientManager;

public class MessageHandler {

	public void messageHandler(Object msg) {
		
	}
}
