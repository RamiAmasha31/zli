Shipping/Order Time system (Threads use: send 24hr order cancel reminder to each customer), Client-Server side, Monthly Store reports (PDF) automate transfer to DB.
