package entities.enumE;
/**
 * operation type
 *
 */

 public enum OpType{
	 Login,
	 Logout,
	 Search,
	 Order,
	 Refresh,
	 ViewMyOrder, 
	 Cancel,
	 Table, Catalog, Indviduals, Birthday, Wedding,Graduation ,MOM,Seedlings,FlowerPots,FlowerBranches,Flowers,
	 ViewCatalog,UpdateSale,UpdateCatalog,
	 Survey, WorkerSurvey, ExpertSurvey, 
     uploadPDF, setDetails, Delete, Edit, ADD,Sales,Details, AddOrder,ViewSales, SaleActivity ,ViewSurvey,OpenSurvey,UnConfirmOrderB_M, ConfirmOrderB_M, ViewMyOrderB_M, ViewReportB_M, MangeAccountsB_M, UnFreezeAccountB_M, ConfirmAccountB_M, FreezeAccountB_M, CreateAccountB_M, ViewReportCEO, ViewSingleQuarterReportCEO, ViewTwoQuarterReportCEO, ApproveEmployeeAccountB_M, MangeEmployeesAccountsB_M, DenyEmployeeAccountB_M, compensation, Messages, CreateComplaint, Compensation, CreateSurvey, Complaints, CheckCustumerId;
 }

