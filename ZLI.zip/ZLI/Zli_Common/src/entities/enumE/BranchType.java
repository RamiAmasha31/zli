package entities.enumE;

public enum BranchType {

	NORTH,SOUTH,WEST,EAST
}