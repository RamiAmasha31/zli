package entities.enumE;

public enum TimeType {
	ReportsTimer,ComplaintsTimer,Deliverytimer, Done, Stop;
	
}
