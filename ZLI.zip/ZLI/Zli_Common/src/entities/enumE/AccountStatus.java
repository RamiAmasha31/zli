package entities.enumE;

public enum AccountStatus {

	FROZEN,PENDING_APPROVAL,CONFIRMED, UNFROZEN
}
