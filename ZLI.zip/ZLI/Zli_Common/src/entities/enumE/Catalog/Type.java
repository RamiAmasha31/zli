package entities.enumE.Catalog;

public enum Type {
	Bouqute,FlowerBranches,FlowerPots,Flowers,Seedlings;
}
