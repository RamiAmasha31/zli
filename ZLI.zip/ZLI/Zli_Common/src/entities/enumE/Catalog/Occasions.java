package entities.enumE.Catalog;

public enum Occasions {
	Birthday,Graduation,MOM,Wedding;
}
