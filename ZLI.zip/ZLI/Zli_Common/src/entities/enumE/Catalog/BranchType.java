package entities.enumE.Catalog;

public enum BranchType {
NORTH,SOUTH,WEST,EAST,ALL;
}
