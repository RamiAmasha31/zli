package entities.enumE.Catalog;

public enum Category {
Item,Product;
}
