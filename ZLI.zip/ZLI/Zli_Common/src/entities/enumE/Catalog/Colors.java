package entities.enumE.Catalog;

public enum Colors {
	Red,Green,Yellow,Pink,Blue,White,Orange,Multicolor,Purple,Black,All;
}