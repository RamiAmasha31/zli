package entities.enumE;
/**
 * enum for login customer status 
 */
public enum DB_Message {
	found, notfound, isLogged,frozen, isDenied, isFrozen;
}
