package entities.enumE;

public enum ReportType {
	
	Performance,Income,Orders
	

}
